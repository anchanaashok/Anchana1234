﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
namespace MvcApplication2.Models
{
    public class usercontext:DbContext
    {
        public usercontext()
            :base("mycon")
        {
            DropCreateDatabaseIfModelChanges<usercontext> d = new DropCreateDatabaseIfModelChanges<usercontext>();
            Database.SetInitializer<usercontext>(d);
        }
            public DbSet<user>users{get;set;}
    }
}