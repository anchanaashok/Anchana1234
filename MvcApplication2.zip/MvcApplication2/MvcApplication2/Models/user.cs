﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace MvcApplication2.Models
{
    public class user
    {
        public int id { get; set; }
        [Required]
        [Display(Name="Username")]
        public String uname { get; set; }
        [Required]
        [Display(Name = "Password")]
        [DataType(DataType.Password,ErrorMessage="Enter a valid password")]
        [MaxLength(10,ErrorMessage="Limit Exceeded")]
        public String pass { get; set; }
    }
}